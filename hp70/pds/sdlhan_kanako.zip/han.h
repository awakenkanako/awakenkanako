#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "trans.h"   //��ȯ ���̺�

#define MAX 256

char ITOA(int a)
{
    switch(a)
    {
    case 0:
	return '0';
    case 1:
	return '1';
    case 2:
	return '2';
    case 3:
	return '3';
    case 4:
	return '4';
    case 5:
	return '5';
    case 6:
	return '6';
    case 7:
	return '7';
    case 8:
	return '8';
    case 9:
	return '9';
    case 10:
	return 'A';
    case 11:
	return 'B';
    case 12:
	return 'C';
    case 13:
	return 'D';
    case 14:
	return 'E';
    case 15:
	return 'F';
    default:
	return '\0';
    }
}

int ATOI(char a)
{
    switch(a)
    {
    case '0':
	return 0;
    case '1':
	return 1;
    case '2':
	return 2;
    case '3':
	return 3;
    case '4':
	return 4;
    case '5':
	return 5;
    case '6':
	return 6;
    case '7':
	return 7;
    case '8':
	return 8;
    case '9':
	return 9;
    case 'A':
	return 10;
    case 'B':
	return 11;
    case 'C':
	return 12;
    case 'D':
	return 13;
    case 'E':
	return 14;
    case 'F':
	return 15;
    default:
	return -1;
    }
}

Uint16* ToHan(const char *str)
{
    Uint16* result = (Uint16*)malloc(sizeof(Uint16*)*256);
    int pos=0;
    int rpos=0;
    int end=0;
    int asc;
    int temp;
    int mode=0;
    while(!end)
    {
	asc = (int)*(str+pos);
	if(!mode)
	{
	    if(asc>=-80 && asc<=-56) {temp=asc; mode=1;}
	    else {*(result+rpos) = asc; rpos++; if(!asc) end=1;}
	}
	else
	{
	    *(result+rpos) = KSCToUnicode((256+temp)*256+(256+asc));
	    temp=0;
	    mode=0;
	    rpos++;
	}
	pos++;
    }
    return result;
}