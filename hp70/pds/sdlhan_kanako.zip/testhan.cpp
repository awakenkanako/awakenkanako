#include <stdlib.h>
#include <stdio.h>
#include "SDL.h" 
#include "SDL_ttf.h"
#include "han.h"


int main (int argc, char* argv[]) 
{
    SDL_Surface *screen, *text;
    TTF_Font *font;
    SDL_Rect dstrect;
    SDL_Color white = { 0xFF, 0xFF, 0xFF, 0};
    SDL_Color black = { 0x00, 0x00, 0x00, 0};
    SDL_Color red = { 0xff, 0x00, 0x00, 0};
    SDL_Init(SDL_INIT_VIDEO|SDL_INIT_AUDIO);

    TTF_Init();
    font = TTF_OpenFont("ngulim.ttf", 30);
    TTF_SetFontStyle(font, TTF_STYLE_ITALIC);
    screen = SDL_SetVideoMode(640, 480, 32, SDL_SWSURFACE);
    SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, white.r, white.g, white.b));
    SDL_UpdateRect(screen, 0, 0, 0, 0);
    Uint16* unicode_text = ToHan("����");
    text = TTF_RenderUNICODE_Shaded(font, unicode_text, red, white);
    //text = TTF_RenderText_Solid(font, "HAJE", red);
    dstrect.x = (screen->w - text->w)/2;
    dstrect.y = (screen->h - text->h)/2;
    dstrect.w = text->w;
    dstrect.h = text->h;
    SDL_BlitSurface(text, NULL, screen, &dstrect);
    SDL_UpdateRect(screen, 0, 0, 0, 0);
    SDL_Delay(3000);
    SDL_FreeSurface(text);
    TTF_CloseFont(font);
    free(unicode_text);
    TTF_Quit();
    SDL_Quit();
    return 0;
}
